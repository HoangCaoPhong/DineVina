# PA3 Sprint Meeting Minutes
**Performed by:** Hoàng Cao Phong and Lương Thiện Nhân | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

## 5 November 2026, 21:30 (ICT) — Sprint Planning and Week 1 Scrum
**Performed by:** Hoàng Cao Phong and Lương Thiện Nhân | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

**Attendees:** Hoàng Cao Phong, Võ Mỹ Ngọc, Lương Thiện Nhân, Nguyễn Trung Kiên, Trương Khánh Duy. **Absences:** none.

### Agenda and decisions
**Performed by:** Hoàng Cao Phong and Lương Thiện Nhân | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

1. Set the PA3 goal: revise Plan and Vision, complete use-case model/specifications/prototypes, and build one end-to-end F3 discovery group.
2. Assign Plan, Changes, UI integration and packaging to Phong; Vision, model and customer use cases to Ngọc; partner/admin cases, sample data and report to Nhân; F3 Spec Kit and API/database to Kiên; F9 use cases and integration check to Duy.
3. Use a separate reviewer for each owner. Record review assignment on Trello; later submission review status must reflect the actual artifact checks.
4. Keep optional RAG/OCR as specified prototypes only. The PA3 implementation target is F3.

### Progress and action register
**Performed by:** Hoàng Cao Phong and Lương Thiện Nhân | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

- Progress at this point: task allocation and the PA2 baseline were available; PA3 deliverables remained in preparation.
- Risks: missing instructor feedback mapping, use-case/prototype coverage, fixture contract drift, and video hosting.
- Actions: each owner prepares their assigned artifact on a PA3 research branch; Phong maintains the single Changes file; Kiên and Phong agree API shapes before UI integration; Nhân records the sample-data schema.


### Three-question Scrum status by member — 5 November
**Performed by:** Hoàng Cao Phong and Lương Thiện Nhân | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

The table summarizes each member's workstream, next action, and relevant project issue.

| Member | Done since the previous week | Planned until next week | Issues or obstacles |
| --- | --- | --- | --- |
| Phong | PA2 Plan and instructor feedback available as revision baseline. | Revise Plan and Changes; coordinate F3 UI integration and package. | Feedback mapping and packaging evidence need a single acceptance check. |
| Ngọc | PA2 Vision available as revision baseline. | Revise Vision, master model, customer specifications and prototypes. | Keep IDs and prototype coverage aligned. |
| Nhân | PA2 partner/admin scope available as revision baseline. | Prepare partner/admin cases, data fixture and report material. | Agree on one fixture contract with the F3 API. |
| Kiên | F3 scope and the PA2 baseline available for Spec Kit planning. | Prepare F3 Spec Kit artifacts, API, persistence and tests. | Agree on UI/API data shapes before integration. |
| Duy | F9 feature scope available in the PA2 Vision. | Specify F9 cases and prototype paths; check integrated F3 behavior. | Keep F9 IDs consistent with the master catalogue. |

## 12 November 2026, 21:30 (ICT) — Week 2 Scrum and Integration Check
**Performed by:** Hoàng Cao Phong and Lương Thiện Nhân | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

**Attendees:** Hoàng Cao Phong, Võ Mỹ Ngọc, Lương Thiện Nhân, Nguyễn Trung Kiên, Trương Khánh Duy. **Absences:** none.

### Three-question Scrum status by member — 12 November
**Performed by:** Hoàng Cao Phong and Lương Thiện Nhân | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

The table summarizes workstream progress, next actions, and integration issues.

| Member | Done since the previous week | Planned until next week | Issues or obstacles |
| --- | --- | --- | --- |
| Phong | PA3 integration baseline and Plan work were in the repository. | Consolidate Plan/Vision changes, connect UI to F3 API and prepare package. | UI/API integration and evidence packaging need a final check. |
| Ngọc | Vision, model and customer specifications were in progress. | Complete 44-requirement mapping, customer specifications and screens; reconcile IDs. | Check model IDs against screen references. |
| Nhân | Data fixture and partner/admin specifications were in progress. | Validate specifications and fixture, and assemble report material. | Keep the fixture contract aligned with the F3 API. |
| Kiên | F3 backend and Spec Kit artifacts had a repository commit dated 12 November. | Finish integration tests and the narrated F3 demo. | Coordinate UI/API integration with Phong. |
| Duy | F9 specification and prototype work was in progress. | Align F9 IDs with the master model and check F3 behavior. | Check F9 identifiers and navigation links. |

### Decisions and follow-up
**Performed by:** Hoàng Cao Phong and Lương Thiện Nhân | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

- Keep the master `UC-AI01`–`UC-AI03` identifiers throughout the final package.
- Show only approved venues in public F3 endpoints, and identify sample data as sample data.
- Run backend lint/tests and frontend build after integration; record skipped live checks separately.
- Publish the narrated demo using an Unlisted YouTube URL and verify playback before packaging. The verified link and dated screenshot appear in the final submission.

## Integration Retrospective: Sprint Review Questions
**Performed by:** Hoàng Cao Phong | **Reviewed by:** Group 08 representative | **Edited by:** Hoàng Cao Phong

This integration retrospective was prepared on 14 November from the submitted artifacts and verification results. It records the five Sprint Review questions as an evidence-based project assessment.

| Required review question | Integration observation |
| --- | --- |
| What went well? | The F3 API, React UI and sample-data path were integrated; backend lint, 25 tests, frontend build and the narrated YouTube demo were checked. |
| What went wrong? | The merged backend initially failed CI lint; the first `dev` frontend did not contain the full F3 UI. |
| What problems occurred and why? | Import ordering and dependency declaration failed Ruff; source integration was incomplete. Remote Supabase checks lacked credentials. |
| What should change next sprint? | Run the full CI/build checklist before each merge, keep one fixture/count contract, and capture live-service results and meeting outcomes at the time they occur. |
| What was learned? | A passed local suite and a configured deployment path prove different things; optional prototypes must be separated from implemented F3 features. |
