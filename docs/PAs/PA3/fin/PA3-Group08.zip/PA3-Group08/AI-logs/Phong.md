# PA3 Individual AI Usage Declaration — Hoàng Cao Phong
**Performed by:** Hoàng Cao Phong | **Reviewed by:** Võ Mỹ Ngọc | **Edited by:** Hoàng Cao Phong

## 1. Declaration and record limits
**Performed by:** Hoàng Cao Phong | **Reviewed by:** Võ Mỹ Ngọc | **Edited by:** Hoàng Cao Phong

I used Gemini for background information search during PA3 and OpenAI Codex for the repository and submission-package work recorded below. The Gemini conversation history, exact prompts, query dates and consulted URLs were not retained, so I cannot reconstruct a source-by-source Gemini log. No factual claim in this submission is presented as verified solely because Gemini suggested it. The Codex entries below are supported by dated repository commits and the resulting files or test records; they summarize tasks rather than quote missing prompt transcripts.

## 2. Usage log
**Performed by:** Hoàng Cao Phong | **Reviewed by:** Võ Mỹ Ngọc | **Edited by:** Hoàng Cao Phong

| Date / tool | Task and material supplied | Output used in PA3 | Human or reproducible verification |
| --- | --- | --- | --- |
| Sprint 3; exact date not retained — Gemini | Background searches related to PA3 planning. Exact prompts and URLs were not preserved. | Helped identify topics to check in the course brief and PA2 baseline; no Gemini passage is cited as a primary source. | The final Plan and Changes register were checked against `PA3-2026.pdf`, the submitted PA2 Plan and the supplied instructor-feedback screenshots. Missing search details remain explicitly unverified. |
| 14 Nov 2026 — OpenAI Codex | Inspected the merged `dev` source, CI failure screenshot and F3 backend/frontend files. | Assisted with backend lint/CI repairs and F3 frontend integration, recorded in commit `ac5785c`. | `ruff check backend` passed; backend pytest returned 25 passed and 2 skipped; frontend production build passed. The skipped checks were not counted as passes. |
| 14 Nov 2026 — OpenAI Codex | Compared PA3 instructions, PA2 reference documents, team PA3 artifacts and Trello task status. | Assisted with assembly and editing of Plan, Vision, Changes, use-case package, Weekly Report and submission checklist; see commits `43e9817` and `7d5862e`. | Checked requirement-to-use-case IDs, rendered Markdown to PDF, inspected representative pages and checked that referenced images loaded. This is document verification, not proof of an independently held review meeting. |
| 14 Nov 2026 — OpenAI Codex | Reviewed F9 specifications against the 32-case catalogue and missing alternative-flow screens. | Canonical `UC-AI01` prototypes and corrected cross-group IDs; later `UC-AI02/03` alternative screens in `UC-AI.md`. | Compared labels with the master model and inspected the generated screens and rendered PDF. The F9 images are design prototypes, not implemented UI. |
| 14 Nov 2026 — OpenAI Codex | Used the application fixture, test suite, disposable PostgreSQL 17 container and source-package files. | `PostgreSQL-Local-Verification.md`, corrected source README and Spec Kit counts. | Reproduced 25 passed / 2 skipped on local PostgreSQL; queried 8 approved and 3 unapproved venues and 21 dishes; separately ran 8 fixture tests. Remote Supabase was not verified. |

## 3. Boundaries
**Performed by:** Hoàng Cao Phong | **Reviewed by:** Võ Mỹ Ngọc | **Edited by:** Hoàng Cao Phong

AI assistance did not establish meeting attendance, reviewer sign-off, instructor permission, or a successful remote Supabase run. Those claims depend on team records or observed tests. The team AI report references the individual member logs; each member remains responsible for the accuracy of their own declaration.
